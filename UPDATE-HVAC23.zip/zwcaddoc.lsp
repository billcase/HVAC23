;; ============================================================================
;; ZWCADDOC.LSP - CHI NAP DUNG 1 LAN TRONG MOI BAN VE
;; ============================================================================
(vl-load-com)
(if (not *HVAC23_DOC_INIT*)
  (progn
    (setq *HVAC23_DOC_INIT* T)
    (vl-catch-all-apply 'setvar (list "SECURELOAD" 0))
    (setq env_var "C:/hvac23/")
    (cond
      ((vl-file-systime (strcat env_var "loadmenu.lsp"))  (load (strcat env_var "loadmenu.lsp")))
      ((vl-file-systime (strcat env_var "loadmenu.zelx")) (load (strcat env_var "loadmenu.zelx")))
    )
  )
)
(princ)
