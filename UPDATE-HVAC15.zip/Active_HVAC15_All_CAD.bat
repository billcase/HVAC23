@echo off
chcp 65001 >nul
set "HVAC_DIR=C:\HVAC15"
set "HVAC_ICON=C:\HVAC15\icon"
set "HVAC_TRUST=C:\HVAC15;C:\HVAC15\..."

echo ========================================================
echo ĐANG CÀI ĐẶT TỰ ĐỘNG C:\HVAC15 CHO MỌI PHIÊN BẢN AUTOCAD
echo ========================================================

:: 1. Lưu biến môi trường HVAC15_RUNTIME_DIR cho Windows User
reg add "HKCU\Environment" /v "HVAC15_RUNTIME_DIR" /t REG_SZ /d "%HVAC_DIR%" /f >nul 2>&1

:: 2. Quét toàn bộ các phiên bản AutoCAD trong Registry (Từ 2007 -> 2027+)
for /f "delims=" %%A in ('reg query "HKCU\Software\Autodesk\AutoCAD" 2^>nul ^| findstr /i "\\R[0-9]"') do (
    for /f "delims=" %%B in ('reg query "%%A" 2^>nul ^| findstr /i "\\ACAD-"') do (
        
        :: Đảm bảo bật ACADLSPASDOC = 1 và APPAUTOLOAD = 14
        reg add "%%B\Variables" /v "APPAUTOLOAD" /t REG_DWORD /d 14 /f >nul 2>&1
        
        :: Duyệt qua tất cả các Profile của từng bản AutoCAD
        for /f "delims=" %%P in ('reg query "%%B\Profiles" 2^>nul ^| findstr /i "\\Profiles\\"') do (
            
            :: 2a. Gắn C:\HVAC15 và C:\HVAC15\icon vào Support File Search Path (ACAD)
            for /f "tokens=2*" %%i in ('reg query "%%P\General" /v "ACAD" 2^>nul ^| findstr /i "REG_"') do (
                echo "%%j" | find /i "%HVAC_DIR%" >nul
                if errorlevel 1 (
                    reg add "%%P\General" /v "ACAD" /t REG_SZ /d "%HVAC_DIR%;%HVAC_ICON%;%%j" /f >nul 2>&1
                )
            )
            
            :: 2b. Gắn C:\HVAC15\icon vào CustomIconPath
            reg add "%%P\General" /v "CustomIconPath" /t REG_SZ /d "%HVAC_ICON%" /f >nul 2>&1
            
            :: 2c. Gắn C:\HVAC15\... vào TRUSTEDPATHS (Không bị hỏi bảng Security)
            reg query "%%P\Variables" /v "TRUSTEDPATHS" >nul 2>&1
            if errorlevel 1 (
                reg add "%%P\Variables" /v "TRUSTEDPATHS" /t REG_SZ /d "%HVAC_TRUST%" /f >nul 2>&1
            ) else (
                for /f "tokens=2*" %%i in ('reg query "%%P\Variables" /v "TRUSTEDPATHS" 2^>nul ^| findstr /i "REG_"') do (
                    echo "%%j" | find /i "%HVAC_DIR%" >nul
                    if errorlevel 1 (
                        reg add "%%P\Variables" /v "TRUSTEDPATHS" /t REG_SZ /d "%HVAC_TRUST%;%%j" /f >nul 2>&1
                    )
                )
            )

            :: 2d. Thêm trực tiếp vào Startup Suite (Appload) của Profile
            reg add "%%P\Dialogs\Appload\Startup" /v "1Startup" /t REG_SZ /d "%HVAC_DIR%\acaddoc.lsp" /f >nul 2>&1
            reg add "%%P\Dialogs\Appload\Startup" /v "NumStartup" /t REG_SZ /d "1" /f >nul 2>&1
        )
    )
)

:: 3. Tạo thêm Cầu nối Bundle ở cả Program Files và AppData trỏ thẳng về C:\HVAC15
:: (Giúp các bản AutoCAD mới cài lần đầu chưa tạo Profile trong Registry vẫn tự động nạp C:\HVAC15)
for %%D in ("%APPDATA%\Autodesk\ApplicationPlugins" "C:\Program Files\Autodesk\ApplicationPlugins") do (
    mkdir "%%~D\HVAC15_Loader.bundle" 2>nul
    if exist "%%~D\HVAC15_Loader.bundle" (
        (
            echo ^<?xml version="1.0" encoding="utf-8"?^>
            echo ^<ApplicationPackage SchemaVersion="1.0" AutodeskProduct="AutoCAD" ProductType="Application" Name="HVAC15 Loader" AppVersion="2027.1.0" ProductCode="{C1502027-BEEF-4321-ABCD-C0FFEE999999}" UpgradeCode="{D1502027-BEEF-4321-ABCD-C0FFEE888888}"^>
            echo   ^<RuntimeRequirements OS="Win32|Win64" Platform="AutoCAD*" SeriesMin="R18.0" SupportPath="C:/HVAC15;C:/HVAC15/icon" /^>
            echo   ^<Components Description="HVAC15 Direct Loader"^>
            echo     ^<RuntimeRequirements OS="Win32|Win64" Platform="AutoCAD*" SeriesMin="R18.0" /^>
            echo     ^<ComponentEntry AppName="HVAC15_AutoDoc" Version="2027.1.0" ModuleName="C:/HVAC15/acaddoc.lsp" PerDocument="True" AppType="AutoLisp" /^>
            echo   ^</Components^>
            echo ^</ApplicationPackage^>
        ) > "%%~D\HVAC15_Loader.bundle\PackageContents.xml"
    )
)

echo.
echo [HOÀN TẤT] Đã gắn cứng C:\HVAC15 vào toàn bộ các phiên bản AutoCAD!
echo Bạn có thể mở AutoCAD để sử dụng ngay.
pause